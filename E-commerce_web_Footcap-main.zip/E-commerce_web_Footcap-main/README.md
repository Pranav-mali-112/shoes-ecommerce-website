#E-commerce_web_Footcap  
An E-commerce Website front-end for online fashionable shoes delivery using html and css.
